import sys
import urllib.parse
import xbmcgui
import xbmcplugin
import requests
import xbmc
import xbmcaddon
import os
import sqlite3
import xbmcvfs
import re
import json
import hashlib
import string
from concurrent.futures import ThreadPoolExecutor, as_completed
import threading

BASE_URL = sys.argv[0]
ADDON_HANDLE = int(sys.argv[1])
ARGS = urllib.parse.parse_qs(sys.argv[2].lstrip('?'))

ADDON = xbmcaddon.Addon()
ADDON_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo('path'))
MEDIA_DIR = os.path.join(ADDON_PATH, "media")

ADDON_DATA_DIR = xbmcvfs.translatePath("special://profile/addon_data/plugin.video.gezkino/")
if not os.path.exists(ADDON_DATA_DIR):
    os.makedirs(ADDON_DATA_DIR)
DB_PATH = os.path.join(ADDON_DATA_DIR, "movie_metadata.db")

def init_db():
    try:
        with sqlite3.connect(DB_PATH) as conn:
            c = conn.cursor()
            c.execute('''CREATE TABLE IF NOT EXISTS movie_cache
                         (search_title TEXT PRIMARY KEY, plot TEXT, rating TEXT,
                          poster_url TEXT, local_poster TEXT, genres_json TEXT,
                          director TEXT, actors_json TEXT)''')
            c.execute('''CREATE TABLE IF NOT EXISTS film_list
                         (hash_id TEXT PRIMARY KEY, title TEXT, video_url TEXT,
                          search_name TEXT, year TEXT, genres_json TEXT)''')
            
            try:
                c.execute("ALTER TABLE movie_cache ADD COLUMN director TEXT")
            except sqlite3.OperationalError:
                pass
            try:
                c.execute("ALTER TABLE movie_cache ADD COLUMN actors_json TEXT")
            except sqlite3.OperationalError:
                pass
            
            conn.commit()
    except Exception as e:
        xbmc.log(f"[GEZ-Kino] Fehler bei DB-Initialisierung: {str(e)}", xbmc.LOGERROR)

init_db()

def should_filter_out(title, channel=""):
    t_low = title.lower()
    c_low = channel.lower()
    if 'zdf-tivi' in c_low or 'zdf-tivi' in t_low or 'tivi' in t_low:
        return True
    if re.search(r'\b(folge|staffel|episode|ep\.|teil)\b', t_low):
        return True
    if re.search(r'\(\d+(\s*[\/\-]\s*\d+)?\)', t_low):
        return True
    if re.search(r'\b\d{1,2}\/\d{1,2}\b', t_low):
        return True
    return False

def clean_title(title):
    year_match = re.search(r'(\d{4})', title)
    year = year_match.group(1) if year_match else None
    clean = title
    markers = [
        ' - Spielfilm', ' – Spielfilm', ' - Spiellfilm', ' – Spiellfilm', ', Spielfilm',
        ' Österreich', ', Deutschland', ', Schweiz', ', Belgien', ', Frankreich', ', Spanien',
        ', Niederlande', ', Irland', ', Luxemburg', ', Italien', ', USA', ', Kosovo',
        ', Großbritannien', ', Tschechische Republik', ', Norwegen', ', BRD', ', Dänemark',
        ', Australien', ', Schweden', ', Video:', ', Präsentiert:', ', Kurzfilm',
        ' Fernsehfilm', ' Heimatfilm', ' - Thriller', ' - Drama',
        ' - Aufstand der Pferdefreunde Spielfilm', '«', '»'
    ]
    for marker in markers:
        clean = re.split(marker, clean, flags=re.I)[0]
    clean = re.sub(r'^(Spielfilm|Spiellfilm):\s*', '', clean, flags=re.I)
    clean = clean.replace('–', '-').replace('—', '-')
    clean = re.sub(r'\(.*?\)', '', clean)
    clean = clean.strip().rstrip('( ,.-_–—»')
    return (clean, year)

_GENRES_MAP = {
    28: 'Action', 12: 'Abenteuer', 16: 'Animation', 35: 'Komödie', 80: 'Krimi', 99: 'Doku',
    18: 'Drama', 10751: 'Familie', 14: 'Fantasy', 36: 'Historie', 27: 'Horror', 10402: 'Musik',
    9648: 'Mystery', 10749: 'Romanze', 878: 'Sci-Fi', 10770: 'TV-Film', 53: 'Thriller',
    10752: 'Krieg', 37: 'Western'
}
_TMDB_KEY = '60b3801a9e76b5706ee2a432f06423e6'

def get_tmdb_data_sync(session, title, year=None):
    try:
        params = {"api_key": _TMDB_KEY, "query": title, "language": "de-DE", "include_adult": "false"}
        if year:
            params["year"] = year
        res = session.get("https://api.themoviedb.org/3/search/movie", params=params, timeout=5).json()
        results = res.get('results', [])
        if not results and year:
            params.pop("year")
            res = session.get("https://api.themoviedb.org/3/search/movie", params=params, timeout=5).json()
            results = res.get('results', [])
        if results:
            movie = results[0]
            movie_id = movie.get('id')
            path = movie.get('poster_path')
            release_date = movie.get('release_date', '')
            tmdb_year = release_date.split('-')[0] if '-' in release_date else None
            
            genres_list = [_GENRES_MAP[gid] for gid in movie.get('genre_ids', []) if gid in _GENRES_MAP]
            if not genres_list:
                genres_list = ['Mediathek']
                
            director = ""
            actors_list = []
            if movie_id:
                try:
                    credits_url = f"https://api.themoviedb.org/3/movie/{movie_id}/credits"
                    c_res = session.get(credits_url, params={"api_key": _TMDB_KEY, "language": "de-DE"}, timeout=5).json()
                    for crew_member in c_res.get('crew', []):
                        if crew_member.get('job') == 'Director':
                            director = crew_member.get('name', '')
                            break
                    actors_list = [cast_member.get('name', '') for cast_member in c_res.get('cast', [])[:5] if cast_member.get('name')]
                except Exception as ce:
                    xbmc.log(f"[GEZ-Kino] Credits Fehler für {title} (ID: {movie_id}): {ce}", xbmc.LOGERROR)

            return {
                "poster": f"https://image.tmdb.org/t/p/w342{path}" if path else "",
                "plot": movie.get('overview', 'Keine Beschreibung verfügbar.'),
                "rating": str(movie.get('vote_average', 'N/A')),
                "genres_list": genres_list,
                "year": tmdb_year,
                "director": director,
                "actors_list": actors_list
            }
    except Exception as e:
        xbmc.log(f"[GEZ-Kino] TMDB Fehler für {title}: {e}", xbmc.LOGERROR)
    return None

def aktualisiere_datenbank():
    pDialog = xbmcgui.DialogProgress()
    pDialog.create('GEZ Kino', 'Starte parallele Abfrage...')

    api_url = 'https://mediathekviewweb.de/api/query'
    headers = {'User-Agent': 'Mozilla/5.0', 'Accept-Encoding': 'gzip, deflate'}
    queries = ['Spielfilm', 'Spielfilme', 'Spielfilm-Highlights', 'Filme', 'Kino - Filme']
    iptv_url = "https://raw.githubusercontent.com/jnk22/kodinerds-iptv/master/iptv/clean/clean_tv_main.m3u"
    skip_words = ["audiodeskription", "audio description", "ad version", "hörfilm", "deskription", "barrierefrei version"]

    def fetch_mediathek(q):
        s = requests.Session()
        payload = {'queries': [{'fields': ['topic'], 'query': q}], 'size': 2000, 'sortBy': 'timestamp', 'sortOrder': 'desc'}
        try:
            r = s.post(api_url, json=payload, headers=headers, timeout=10)
            if r.status_code == 200:
                return r.json().get('result', {}).get('results', [])
        except Exception as e:
            xbmc.log(f"[GEZ-Kino] API Fehler bei {q}: {e}", xbmc.LOGERROR)
        return []

    def fetch_iptv():
        s = requests.Session()
        try:
            r = s.get(iptv_url, timeout=5)
            if r.status_code == 200:
                return r.text.splitlines()
        except Exception as e:
            xbmc.log(f"[GEZ-Kino] IPTV Fehler: {e}", xbmc.LOGERROR)
        return []

    pDialog.update(5, 'Lade Mediatheken + IPTV parallel...')
    raw_mediathek = {}
    raw_iptv_lines = []

    with ThreadPoolExecutor(max_workers=6) as ex:
        mediathek_futures = {ex.submit(fetch_mediathek, q): q for q in queries}
        iptv_future = ex.submit(fetch_iptv)

        for future in as_completed(list(mediathek_futures.keys()) + [iptv_future]):
            if pDialog.iscanceled():
                ex.shutdown(wait=False, cancel_futures=True)
                return
            if future is iptv_future:
                raw_iptv_lines = future.result()
            else:
                raw_mediathek[mediathek_futures[future]] = future.result()

    pDialog.update(28, 'Verarbeite Ergebnisse...')
    seen_titles = set()
    results_map = {}

    for q in queries:
        for m in raw_mediathek.get(q, []):
            url = m.get('url_video', '')
            title = m.get('title', '')
            channel = m.get('channel', '')
            
            if not url or not title or url in results_map:
                continue
            if any(x in title.lower() for x in skip_words):
                continue
            if should_filter_out(title, channel):
                continue

            clean_name, prod_year = clean_title(title)
            if not clean_name:
                continue
            title_norm = clean_name.strip().lower()
            if title_norm in seen_titles:
                continue
            if m.get('duration', 0) < 4680:
                continue
            seen_titles.add(title_norm)
            results_map[url] = {
                'title': clean_name, 'year': prod_year if prod_year else '', 'video_url': url, 'search': clean_name,
                'plot': 'Keine Info verfügbar.', 'rating': 'N/A', 'genres_list': ['Mediathek'], 'thumb': '',
                'director': '', 'actors_list': []
            }
            
    for i in range(len(raw_iptv_lines)):
        if raw_iptv_lines[i].startswith("#EXTINF"):
            logo_match = re.search(r'tvg-logo="([^"]+)"', raw_iptv_lines[i])
            name = raw_iptv_lines[i].split(',')[-1].strip()
            if i + 1 < len(raw_iptv_lines) and raw_iptv_lines[i + 1].startswith("http"):
                url = raw_iptv_lines[i + 1].strip()
                results_map[url] = {
                    'title': f"[TV] {name}", 'year': '', 'video_url': url, 'search': name,
                    'plot': 'Live-TV Sender', 'rating': 'LIVE', 'genres_list': ['Live-TV'],
                    'logo_url': logo_match.group(1) if logo_match else "", 'thumb': '',
                    'director': '', 'actors_list': []
                }

    if pDialog.iscanceled():
        return

    pDialog.update(32, 'Prüfe Cache...')
    to_fetch = []

    movie_urls = [url for url, m in results_map.items() if 'Live-TV' not in m['genres_list']]
    cache_key_map = {f"{results_map[url]['search']}_{results_map[url]['year']}": url for url in movie_urls}

    try:
        with sqlite3.connect(DB_PATH) as conn:
            for url, movie in results_map.items():
                if 'Live-TV' in movie['genres_list']:
                    movie['thumb'] = movie.get('logo_url', '')

            if cache_key_map:
                keys = list(cache_key_map.keys())
                placeholders = ','.join('?' * len(keys))
                rows = conn.execute(
                    f"SELECT search_title, plot, rating, local_poster, genres_json, director, actors_json FROM movie_cache WHERE search_title IN ({placeholders})",
                    keys
                ).fetchall()
                cached = {row[0]: row for row in rows}

                for cache_key, url in cache_key_map.items():
                    movie = results_map[url]
                    if cache_key in cached:
                        row = cached[cache_key]
                        
                        if len(row) > 6 and row[5] is not None and row[6] is not None:
                            movie['plot'], movie['rating'], movie['thumb'] = row[1], row[2], row[3] or ''
                            movie['genres_list'] = json.loads(row[4])
                            movie['director'] = row[5]
                            movie['actors_list'] = json.loads(row[6]) if row[6] else []
                        else:
                            to_fetch.append((url, movie, cache_key))
                        
                        if not movie['year'] and '_' in cache_key:
                            possible_year = cache_key.split('_')[-1]
                            if possible_year.isdigit() and len(possible_year) == 4:
                                movie['year'] = possible_year
                    else:
                        to_fetch.append((url, movie, cache_key))
    except Exception as e:
        xbmc.log(f"[GEZ-Kino] Cache-Prüfung Fehler: {e}", xbmc.LOGERROR)

    total_fetch = len(to_fetch)
    tmdb_results = {}
    completed_count = [0]
    count_lock = threading.Lock()
    _tl = threading.local()

    def _sess():
        if not hasattr(_tl, 's'):
            _tl.s = requests.Session()
        return _tl.s

    def _fetch(args):
        url, movie, cache_key = args
        tmdb = get_tmdb_data_sync(_sess(), movie['search'], movie['year'])
        with count_lock:
            completed_count[0] += 1
        return url, cache_key, tmdb

    if total_fetch > 0:
        pDialog.update(35, f'TMDB: 0 / {total_fetch}...')
        with ThreadPoolExecutor(max_workers=20) as executor:
            future_map = {executor.submit(_fetch, args): args for args in to_fetch}
            for future in as_completed(future_map):
                if pDialog.iscanceled():
                    executor.shutdown(wait=False, cancel_futures=True)
                    pDialog.close()
                    return
                url, cache_key, tmdb = future.result()
                tmdb_results[url] = (cache_key, tmdb)
                done = completed_count[0]
                if done % 10 == 0 or done == total_fetch:
                    pct = 35 + int((done / total_fetch) * 57)
                    pDialog.update(pct, f'TMDB: {done} / {total_fetch}...')

    pDialog.update(94, 'Speichere in Datenbank...')
    try:
        with sqlite3.connect(DB_PATH) as conn:
            conn.execute("DELETE FROM film_list")
            for url, (cache_key, tmdb) in tmdb_results.items():
                movie = results_map[url]
                if tmdb:
                    movie['plot'] = tmdb['plot']
                    movie['rating'] = tmdb['rating']
                    movie['genres_list'] = tmdb['genres_list']
                    movie['thumb'] = tmdb['poster']
                    movie['director'] = tmdb['director']
                    movie['actors_list'] = tmdb['actors_list']
                    if tmdb.get('year'):
                        movie['year'] = tmdb['year']
                    conn.execute(
                        "INSERT OR REPLACE INTO movie_cache VALUES (?,?,?,?,?,?,?,?)",
                        (cache_key, tmdb['plot'], tmdb['rating'], tmdb['poster'], tmdb['poster'], 
                         json.dumps(tmdb['genres_list']), tmdb['director'], json.dumps(tmdb['actors_list']))
                    )
                else:
                    conn.execute(
                        "INSERT OR REPLACE INTO movie_cache VALUES (?,?,?,?,?,?,?,?)",
                        (cache_key, movie['plot'], movie['rating'], movie['thumb'], movie['thumb'], 
                         json.dumps(movie['genres_list']), '', '[]')
                    )
            for url, movie in results_map.items():
                final_year = str(movie['year']).strip()
                if not final_year or final_year.lower() == 'none' or not final_year.isdigit():
                    final_year = ''
                conn.execute(
                    "INSERT OR REPLACE INTO film_list VALUES (?,?,?,?,?,?)",
                    (hashlib.md5(url.encode()).hexdigest(), movie['title'], url,
                     movie['search'], final_year, json.dumps(movie['genres_list']))
                )
            conn.commit()
    except Exception as e:
        xbmc.log(f"[GEZ-Kino] DB Speicherfehler: {e}", xbmc.LOGERROR)

    pDialog.close()
    xbmcgui.Dialog().notification('GEZ Kino', 'Datenbank erfolgreich aktualisiert!', xbmcgui.NOTIFICATION_INFO, 3000)
    xbmc.executebuiltin('Container.Refresh')

def hole_lokale_filme_aus_db(genre_filter, suchbegriff_suche=None, start_char=None, year_filter=None, rating_range=None):
    filme_liste = []
    try:
        with sqlite3.connect(DB_PATH) as conn:
            c = conn.cursor()
            c.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='film_list'")
            if not c.fetchone():
                return None
            rows = conn.execute("""
                SELECT f.title, f.video_url, f.search_name, f.year, f.genres_json, c.local_poster, c.plot, c.rating, c.director, c.actors_json
                FROM film_list f
                LEFT JOIN movie_cache c ON (f.search_name || '_' || f.year) = c.search_title
            """).fetchall()
            if not rows:
                return None
            for r in rows:
                g_list = json.loads(r[4])
                is_tv = 'Live-TV' in g_list
                title = r[0]
                film_year = r[3]
                rating = r[7]
                director = r[8] if r[8] else ""
                actors = json.loads(r[9]) if r[9] else []
                
                if suchbegriff_suche:
                    sb = suchbegriff_suche.lower()
                    actors_combined = " ".join(actors).lower()
                    if sb not in title.lower() and sb not in director.lower() and sb not in actors_combined:
                        continue
                        
                if start_char:
                    first_char = title[0].upper()
                    if start_char == '#':
                        if first_char.isalpha():
                            continue
                    else:
                        if first_char != start_char:
                            continue
                
                if year_filter:
                    if film_year != year_filter:
                        continue
                
                if rating_range is not None:
                    try:
                        r_val = float(rating)
                        start_range = float(rating_range)
                
                        if start_range == 9.0:
                            if not (start_range <= r_val <= start_range + 1):
                                continue
                        else:
                            if not (start_range <= r_val < start_range + 1):
                                continue
                    except:
                        continue

                
                if genre_filter not in ['AZ', 'YEAR', 'RATING']:
                    if genre_filter == 'Live-TV':
                        if not is_tv: continue
                    elif genre_filter == 'Alle':
                        if is_tv: continue
                    elif genre_filter == 'Sonstige':
                        if is_tv or (g_list and g_list != ['Mediathek']): continue
                    else:
                        if genre_filter not in g_list: continue
                
                filme_liste.append({
                    "title": title, "url": r[1], "desc": r[6] if r[6] else 'Keine Beschreibung.',
                    "rating": rating if rating else 'N/A', "thumb": r[5] if r[5] else '', "genres": g_list,
                    "year": film_year, "director": director, "actors": actors
                })
        
        filme_liste.sort(key=lambda x: x['title'].lower())
        return filme_liste
    except Exception as e:
        xbmc.log(f"[GEZ-Kino] DB Ladefehler: {e}", xbmc.LOGERROR)
        return []

def zeige_hauptmenue():
    p_icon1 = os.path.join(MEDIA_DIR, "icon1.png")
    p_icon2 = os.path.join(MEDIA_DIR, "icon2.png")
    p_icon3 = os.path.join(MEDIA_DIR, "icon3.png")
    p_icon4 = os.path.join(MEDIA_DIR, "icon4.png")
    p_icon5 = os.path.join(MEDIA_DIR, "icon5.png")
    p_icon6 = os.path.join(MEDIA_DIR, "icon6.png")
    p_icon7 = os.path.join(MEDIA_DIR, "icon7.png") 
    
    li1 = xbmcgui.ListItem(label="[ Alle Spielfilme ]")
    li1.setInfo('video', {'title': "Alle Spielfilme", 'plot': "Zeigt die komplette Liste vieler Spielfilme aus den öffentlich-rechtlichen Mediatheken an. Komplett alphabetisch sortiert."})
    li1.setArt({'icon': p_icon1, 'thumb': p_icon1})
    xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=f"{BASE_URL}?action=list&query=Alle", listitem=li1, isFolder=True)
    
    li_az = xbmcgui.ListItem(label="[ Filme A-Z ]")
    li_az.setInfo('video', {'title': "Filme A-Z", 'plot': "Durchsuche die Filmliste alphabetisch."})
    li_az.setArt({'icon': p_icon5, 'thumb': p_icon5})
    xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=f"{BASE_URL}?action=az_menu", listitem=li_az, isFolder=True)
    
    li_year = xbmcgui.ListItem(label="[ Nach Jahren sortiert ]")
    li_year.setInfo('video', {'title': "Nach Jahren sortiert", 'plot': "Zeigt die Filme nach Produktionsjahren gruppiert an."})
    li_year.setArt({'icon': p_icon6, 'thumb': p_icon6})
    xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=f"{BASE_URL}?action=years_menu", listitem=li_year, isFolder=True)

    li_rating = xbmcgui.ListItem(label="[ Nach Bewertung sortiert ]")
    li_rating.setInfo('video', {'title': "Nach Bewertung sortiert", 'plot': "Filme sortiert nach TMDB-Bewertung."})
    li_rating.setArt({'icon': p_icon7, 'thumb': p_icon7})
    xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=f"{BASE_URL}?action=rating_menu", listitem=li_rating, isFolder=True)

    li2 = xbmcgui.ListItem(label="[ Nach Genres sortiert ]")
    li2.setInfo('video', {'title': "Nach Genres sortiert", 'plot': "Öffnet das Genre-Menü. Hier kannst du gezielt nach Kategorien wie Krimi, Action, Drama, Komödien oder Dokumentationen suchen."})
    li2.setArt({'icon': p_icon2, 'thumb': p_icon2})
    xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=f"{BASE_URL}?action=genres_menu", listitem=li2, isFolder=True)
    
    li3 = xbmcgui.ListItem(label="[ Film / Regie / Cast suchen... ]")
    li3.setInfo('video', {'title': "Suchen", 'plot': "Öffnet eine Tastatur, um die lokale Datenbank gezielt nach Filmtitel, Regisseur oder Schauspielern zu durchsuchen."})
    li3.setArt({'icon': p_icon3, 'thumb': p_icon3})
    xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=f"{BASE_URL}?action=search", listitem=li3, isFolder=True)
    
    li4 = xbmcgui.ListItem(label="[ Mediathek Datenbank aktualisieren ]")
    li4.setInfo('video', {'title': "Datenbank aktualisieren", 'plot': "Startet den Suchlauf. Lädt frische Filme aus den Mediatheken."})
    li4.setArt({'icon': p_icon4, 'thumb': p_icon4})
    xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=f"{BASE_URL}?action=sync", listitem=li4, isFolder=False)
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def zeige_az_menue():
    buchstaben = ['#'] + list(string.ascii_uppercase)
    for buchstabe in buchstaben:
        url = f"{BASE_URL}?action=list&query=AZ&char={buchstabe}"
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=xbmcgui.ListItem(label=buchstabe), isFolder=True)
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def zeige_jahre_menue():
    jahre = []
    try:
        with sqlite3.connect(DB_PATH) as conn:
            c = conn.cursor()
            rows = c.execute("""
                SELECT DISTINCT year 
                FROM film_list 
                WHERE year IS NOT NULL 
                  AND year != '' 
                  AND LENGTH(year) = 4 
                  AND year GLOB '[0-9][0-9][0-9][0-9]'
            """).fetchall()
            jahre = [r[0] for r in rows]
            jahre.sort(reverse=True)
    except Exception as e:
        xbmc.log(f"[GEZ-Kino] Fehler beim Laden der Jahre: {e}", xbmc.LOGERROR)

    if not jahre:
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url="", listitem=xbmcgui.ListItem(label="Keine Jahresdaten gefunden. Bitte DB aktualisieren."), isFolder=False)
    else:
        for jahr in jahre:
            url = f"{BASE_URL}?action=list&query=YEAR&year={jahr}"
            xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=xbmcgui.ListItem(label=f"Jahr {jahr}"), isFolder=True)
            
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def zeige_rating_menue():
    for i in range(10):
        label = f"Bewertung {i}-{i+1}"
        url = f"{BASE_URL}?action=list&query=RATING&range={i}"
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=xbmcgui.ListItem(label=label), isFolder=True)
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def zeige_genre_menue():
    genres = [
        ("Live-TV", "Live-TV"), ("Action", "Action"),
        ("Abenteuer", "Abenteuer"), ("Animation", "Animation"), ("Komoedien", "Komödie"),
        ("Krimi", "Krimi"), ("Dokumentationen", "Doku"), ("Dramen", "Drama"),
        ("Familie", "Familie"), ("Fantasy", "Fantasy"), ("Historie", "Historie"),
        ("Horror", "Horror"), ("Musik", "Musik"), ("Mystery", "Mystery"),
        ("Liebesfilme und Romantik", "Romanze"), ("Science Fiction", "Sci-Fi"),
        ("TV-Film", "TV-Film"), ("Thriller", "Thriller"), ("Krieg", "Krieg"),
        ("Western", "Western"), ("Sonstige (Unkategorisiert)", "Sonstige")
    ]
    for label, internal_name in genres:
        url = f"{BASE_URL}?action=list&query={urllib.parse.quote_plus(internal_name)}"
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=xbmcgui.ListItem(label=label), isFolder=True)
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def zeige_filmliste(genre_query, search_str=None, start_char=None, year_filter=None, rating_range=None):
    xbmcplugin.setContent(ADDON_HANDLE, 'movies')
    filme = hole_lokale_filme_aus_db(genre_query, suchbegriff_suche=search_str, start_char=start_char, year_filter=year_filter, rating_range=rating_range)
    if filme is None:
        if xbmcgui.Dialog().yesno("Datenbank leer", "Die lokale Datenbank ist leer. Jetzt aktualisieren?"):
            aktualisiere_datenbank()
            filme = hole_lokale_filme_aus_db(genre_query, suchbegriff_suche=search_str, start_char=start_char, year_filter=year_filter, rating_range=rating_range)
        else:
            filme = []
    if not filme:
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url="", listitem=xbmcgui.ListItem(label="Keine Filme gefunden."), isFolder=False)
        xbmcplugin.endOfDirectory(ADDON_HANDLE)
        return
    for film in filme:
        display_label = film['title']
        if film['year']:
            display_label += f" ({film['year']})"
        if film['rating'] and film['rating'] not in ['N/A', 'LIVE']:
            display_label += f" [★ {film['rating']}]"
        
        meta_plot = ""
        if film.get('director'):
            meta_plot += f"Regie: {film['director']}\n"
        if film.get('actors'):
            meta_plot += f"Cast: {', '.join(film['actors'])}\n"
        if meta_plot:
            meta_plot += "--------------------------------------------------------\n"
        meta_plot += film['desc']
            
        li = xbmcgui.ListItem(label=display_label)
        
        try:
            video_info = li.getVideoInfoTag()
            
            try: video_info.setTitle(film['title'])
            except: pass
            
            try: video_info.setPlot(meta_plot)
            except: pass
            
            try: 
                if film['genres']: video_info.setGenres(film['genres'])
            except: pass
            
            try:
                if film['year'] and film['year'].isdigit():
                    video_info.setPremiered(f"{film['year']}-01-01")
            except: pass
            
            try:
                if film['rating'] and film['rating'] not in ['N/A', 'LIVE']:
                    video_info.setRating(float(film['rating']))
            except: pass
            
            try:
                if film.get('director'):
                    video_info.setDirectors([film['director']])
            except: pass
            
            try:
                if film.get('actors'):
                    cast_objects = []
                    for actor in film['actors']:
                        try: cast_objects.append(xbmcgui.ListItemCastAndRole(name=actor, role=""))
                        except: pass
                    if cast_objects:
                        video_info.setCast(cast_objects)
            except: pass
        except:
            info_dict = {
                'title': film['title'], 
                'plot': meta_plot,
                'genre': ", ".join(film['genres']),
                'year': int(film['year']) if film['year'] and film['year'].isdigit() else 0,
                'rating': float(film['rating']) if film['rating'] not in ['N/A', 'LIVE'] else 0.0,
                'director': film.get('director', ''),
                'cast': film.get('actors', [])
            }
            li.setInfo('video', info_dict)
            
        art_dict = {}
        if film['thumb']:
            art_dict['poster'] = film['thumb']
            art_dict['thumb'] = film['thumb']
            art_dict['icon'] = film['thumb']
            art_dict['fanart'] = film['thumb']
        li.setArt(art_dict)
        li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=film['url'], listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

action = ARGS.get('action', [None])[0]
query = ARGS.get('query', [None])[0]
char = ARGS.get('char', [None])[0]
year_param = ARGS.get('year', [None])[0]
range_param = ARGS.get('range', [None])[0]

if action == 'list' and query == 'AZ':
    zeige_filmliste('AZ', start_char=char)
elif action == 'list' and query == 'YEAR':
    zeige_filmliste('YEAR', year_filter=year_param)
elif action == 'list' and query == 'RATING':
    zeige_filmliste('RATING', rating_range=range_param)
elif action == 'list' and query:
    zeige_filmliste(query)
elif action == 'az_menu':
    zeige_az_menue()
elif action == 'years_menu':
    zeige_jahre_menue()
elif action == 'rating_menu':
    zeige_rating_menue()
elif action == 'genres_menu':
    zeige_genre_menue()
elif action == 'sync':
    aktualisiere_datenbank()
elif action == 'search':
    kb = xbmc.Keyboard('', 'Film, Regie oder Schauspieler suchen...')
    kb.doModal()
    if kb.isConfirmed() and kb.getText():
        zeige_filmliste('Alle', search_str=kb.getText())
else:
    zeige_hauptmenue()
